#!/usr/bin/env node
/* fly_autotest.js — autonomous fly test: the first Stage-4 dry run.
 *
 * Arms itself for the NEXT weekday 9:47 ET (13:47 UTC — 5 min after the
 * vol_wide feed). Then:
 *   0. SAFETY: aborts if any XSP option position already exists.
 *   1. CALM GATE (Yahoo): VIX < 22, VIX day-change < +8%, |SPY move from open| < 0.75%.
 *      Not calm -> logs NO-GO and exits. No trade.
 *   2. GEOMETRY: center = live S&P/10 rounded (fresh, not the 9:40 open);
 *      wing = today's vol_wide XSP row from pmtracker_multi_log.jsonl
 *      (fallback: computed from live VIX at 1.75x expected 1-day move).
 *   3. SUBMIT via /place_test_fly WITHOUT credits -> fly_exec snapshot-prices
 *      at submit time (fixes the staleness that stranded this morning's put).
 *   4. MONITOR the server log for the [fly] result line (up to 150s).
 *        ok:true            -> "FLY ON — riding to cash settlement." Done.
 *        no-fill            -> ONE retry after 4 min (fresh snapshots), then stop.
 *        orphan_flattened   -> report round trip. Done.
 *        orphan_unresolved  -> SHORTS-ONLY cleanup: BUY MKT each short conId
 *                              from fly_legs_today.json, orders left working
 *                              (longs are harmless; they ride or expire).
 *
 * Requires tonight's patches deployed (fly-leg exclusion + no-zombie) and
 * FLY_TEST_ENABLED=true still in .env.
 *
 * Launch:  pm2 start fly_autotest.js --name fly-autotest --no-autorestart
 * Review:  pm2 logs fly-autotest --lines 60 --nostream
 */
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const TARGET = { h: 13, m: 47 };            // UTC (= 9:47 ET)
const SERVER_LOG = '/root/.pm2/logs/ibkr-webhook-out.log';
const JSONL = path.join(__dirname, 'pmtracker_multi_log.jsonl');
const LEGS_FILE = path.join(__dirname, 'fly_legs_today.json');
const ACCOUNT = process.env.ACCOUNT || 'DUR110649';
const log = (m) => console.log(`[${new Date().toISOString()}] ${m}`);

function yahoo(sym) {
  const enc = encodeURIComponent(sym);
  const out = execSync(`curl -s -H 'User-Agent: Mozilla/5.0' "https://query1.finance.yahoo.com/v8/finance/chart/${enc}?interval=1d&range=2d"`, { timeout: 20000 }).toString();
  const m = JSON.parse(out).chart.result[0].meta;
  return { last: m.regularMarketPrice, prevClose: m.chartPreviousClose ?? m.previousClose, open: (JSON.parse(out).chart.result[0].indicators.quote[0].open || []).filter(x => x != null).pop() };
}

function nextTargetMs() {
  const now = new Date();
  let t = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), TARGET.h, TARGET.m, 0));
  if (t <= now) t = new Date(t.getTime() + 24 * 3600 * 1000);
  while ([0, 6].includes(t.getUTCDay())) t = new Date(t.getTime() + 24 * 3600 * 1000);  // skip weekend
  return t.getTime() - now.getTime();
}

function todayUTC() {
  const n = new Date();
  return `${n.getUTCFullYear()}-${String(n.getUTCMonth() + 1).padStart(2, '0')}-${String(n.getUTCDate()).padStart(2, '0')}`;
}

function readResultAfter(tsMs) {
  try {
    const lines = fs.readFileSync(SERVER_LOG, 'utf8').split('\n');
    for (let i = lines.length - 1; i >= 0; i--) {
      const idx = lines[i].indexOf('[fly] result: ');
      if (idx === -1) continue;
      const tm = lines[i].match(/\[(\d{4}-\d{2}-\d{2}T[\d:.]+Z)\]/);
      if (tm && new Date(tm[1]).getTime() < tsMs) return null;   // stale result from an earlier run
      return JSON.parse(lines[i].slice(idx + '[fly] result: '.length));
    }
  } catch (e) { log('result read err: ' + e.message); }
  return null;
}

function shortsCleanup() {
  let shorts = [];
  try { const j = JSON.parse(fs.readFileSync(LEGS_FILE, 'utf8')); shorts = j.shorts || []; } catch (e) {}
  if (!shorts.length) return log('cleanup: no shorts list available — MANUAL CHECK NEEDED');
  const { IBApi, EventName, SecType, OrderAction, OrderType } = require('@stoqey/ib');
  const ib = new IBApi({ host: '127.0.0.1', port: +(process.env.IB_PORT || 4002), clientId: 0 });
  let nextId = null;
  ib.on(EventName.error, (err, code, reqId) => { if (![2104, 2106, 2107, 2158].includes(code)) log(`[ib] ${code} ${reqId}: ${err && err.message ? err.message : err}`); });
  ib.on(EventName.orderStatus, (id, st, f, r, px) => log(`[cleanup status] #${id} ${st}${px ? ' @' + px : ''}`));
  ib.on(EventName.nextValidId, (id) => {
    if (nextId != null) return; nextId = id;
    const held = [];
    ib.on(EventName.position, (acct, c, pos) => { if (c.secType === SecType.OPT && pos < 0 && shorts.includes(c.conId)) held.push(c); });
    ib.on(EventName.positionEnd, () => {
      ib.cancelPositions();
      if (!held.length) { log('cleanup: no short fly legs actually held — nothing to do'); return setTimeout(() => process.exit(0), 2000); }
      for (const c of held) {
        const oid = nextId++;
        log(`cleanup #${oid}: BUY 1 ${c.symbol} ${c.right}${c.strike} MKT (closing short; order stays working)`);
        ib.placeOrder(oid, { conId: c.conId, symbol: c.symbol, secType: SecType.OPT, exchange: 'SMART', currency: 'USD' },
          { action: OrderAction.BUY, orderType: OrderType.MKT, totalQuantity: 1, account: ACCOUNT, transmit: true });
      }
      setTimeout(() => { log('cleanup orders placed and left working — verify after 15:50'); process.exit(0); }, 30000);
    });
    ib.reqPositions();
  });
  ib.connect();
}

function attempt(n) {
  // calm gate — fresh every attempt
  let vix, spy;
  try { vix = yahoo('^VIX'); spy = yahoo('SPY'); } catch (e) { log('NO-GO: quote fetch failed: ' + e.message); return process.exit(0); }
  const vixChg = vix.prevClose ? (vix.last / vix.prevClose - 1) * 100 : 0;
  const spyMove = spy.open ? Math.abs(spy.last / spy.open - 1) * 100 : 99;
  log(`gate: VIX ${vix.last} (${vixChg.toFixed(1)}% d/d), SPY ${spyMove.toFixed(2)}% off open`);
  if (vix.last >= 22 || vixChg >= 8 || spyMove >= 0.75) { log('NO-GO: not calm — standing down, no trade today'); return process.exit(0); }

  // geometry — live center, feed wing
  let spx; try { spx = yahoo('^GSPC').last; } catch (e) { log('NO-GO: SPX fetch failed'); return process.exit(0); }
  const center = Math.round(spx / 10);
  let wing = null;
  try {
    const rows = fs.readFileSync(JSONL, 'utf8').split('\n').filter(Boolean).map(JSON.parse);
    const r = rows.reverse().find(r => r.variant === 'vol_wide' && r.symbol === 'XSP' && r.date === todayUTC());
    if (r && r.intended_fly) wing = r.intended_fly.wing_pts;
  } catch (e) {}
  if (!wing) { wing = Math.max(2, Math.round(center * (vix.last / 100 / 15.87) * 1.75)); log(`wing fallback computed: ${wing}`); }
  log(`attempt ${n}: XSP center ${center} wing ${wing} x1 — snapshot-priced (no model credits)`);

  const submitTs = Date.now();
  try {
    const resp = execSync(`curl -s -X POST localhost:3000/place_test_fly -H 'Content-Type: application/json' -d '{"symbol":"XSP","center":${center},"wing":${wing},"contracts":1}'`, { timeout: 15000 }).toString();
    log('endpoint: ' + resp.trim());
  } catch (e) { log('submit failed: ' + e.message); return process.exit(1); }

  // monitor for the result line
  let polls = 0;
  const iv = setInterval(() => {
    polls++;
    const res = readResultAfter(submitTs);
    if (!res && polls < 30) return;
    clearInterval(iv);
    if (!res) { log('no [fly] result seen in 150s — MANUAL CHECK NEEDED'); return process.exit(1); }
    log('result: ' + JSON.stringify(res));
    if (res.ok) { log(`*** FLY ON: XSP ${res.center}±${res.wing}, credit $${res.real_fill_credit} — riding to cash settlement ***`); return process.exit(0); }
    if (res.orphan_unresolved) { log('orphan unresolved — running SHORTS-ONLY cleanup'); return shortsCleanup(); }
    if (res.orphan_flattened) { log(`orphan flattened, round trip $${res.orphan_pl_dollars} — done for today`); return process.exit(0); }
    // plain no-fill
    if (n < 2) { log('no fill — one retry in 4 min with fresh snapshots'); return setTimeout(() => attempt(n + 1), 240000); }
    log('no fill on retry — standing down; fill-shading data logged for review');
    process.exit(0);
  }, 5000);
}

const wait = nextTargetMs();
log(`armed — sleeping ${(wait / 3600000).toFixed(1)} h until the next weekday 9:47 ET, then running the autonomous fly test`);
setTimeout(() => attempt(1), wait);
